# -*- coding: utf-8 -*-
"""Arma el folleto A5 doble cara de stockIAte.

Para cambiar el destino del QR (por ejemplo cuando ngrok cambia de URL),
editá URL y volvé a correr:  python3 armar.py
"""
import base64
import os
import sys

import qrcode
from qrcode.constants import ERROR_CORRECT_H
from playwright.sync_api import sync_playwright

FORMATO = "triptico"   # "triptico" (A4 apaisada) o "a5" (folleto doble cara)

URL = "https://atrium-overtime-deluxe.ngrok-free.dev/stockiate/tesis_enzo/login.html"

AQUI = os.path.dirname(os.path.abspath(__file__))

FORMATOS = {
    "triptico": dict(plantilla="plantilla_triptico.html", html="triptico.html",
                     pdf="stockIAte_triptico_A4.pdf", ancho="297mm", alto="210mm",
                     caras=["exterior", "interior"], vp=(1123, 794)),
    "a5":       dict(plantilla="plantilla.html", html="folleto.html",
                     pdf="stockIAte_folleto_A5.pdf", ancho="148mm", alto="210mm",
                     caras=["frente", "dorso"], vp=(560, 794)),
}
CFG = FORMATOS[FORMATO]
PLANTILLA, SALIDA_HTML, SALIDA_PDF = CFG["plantilla"], CFG["html"], CFG["pdf"]
ANCHO, ALTO, CARAS = CFG["ancho"], CFG["alto"], CFG["caras"]
VP_W, VP_H = CFG["vp"]
MASCOTA = os.path.join(AQUI, "..", "figuras", "logo_mascota.png")


def qr_base64(url: str) -> str:
    qr = qrcode.QRCode(error_correction=ERROR_CORRECT_H, box_size=20, border=2)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#0A1020", back_color="white").convert("RGB")
    ruta = os.path.join(AQUI, "qr.png")
    img.save(ruta)
    print(f"QR generado · versión {qr.version} · {url}")
    return base64.b64encode(open(ruta, "rb").read()).decode()


def main():
    url = sys.argv[1] if len(sys.argv) > 1 else URL
    plantilla = open(os.path.join(AQUI, PLANTILLA), encoding="utf-8").read()
    html = (plantilla
            .replace("__QR__", qr_base64(url))
            .replace("__MASCOTA__", base64.b64encode(open(MASCOTA, "rb").read()).decode()))

    salida_html = os.path.join(AQUI, SALIDA_HTML)
    open(salida_html, "w", encoding="utf-8").write(html)

    with sync_playwright() as pw:
        nav = pw.chromium.launch()
        pag = nav.new_page()
        pag.goto("file://" + salida_html, wait_until="load")
        pag.emulate_media(media="print")
        pag.pdf(path=os.path.join(AQUI, SALIDA_PDF),
                width=ANCHO, height=ALTO,
                print_background=True, margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
        pag.set_viewport_size({"width": VP_W, "height": VP_H})
        for i, cara in enumerate(CARAS, start=1):
            pag.locator(f".{cara}").screenshot(path=os.path.join(AQUI, f"vista_{i}_{cara}.png"))
        nav.close()

    print("Listo:", SALIDA_PDF)


if __name__ == "__main__":
    main()
