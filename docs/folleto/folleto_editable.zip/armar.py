# -*- coding: utf-8 -*-
"""Arma el folleto A5 doble cara de stockIAte.

Para cambiar el destino del QR (por ejemplo cuando ngrok cambia de URL),
editá URL y volvé a correr:  python3 armar.py
"""
import base64
import os
import sys

import qrcode
from qrcode.constants import ERROR_CORRECT_H
from playwright.sync_api import sync_playwright

URL = "https://atrium-overtime-deluxe.ngrok-free.dev/stockiate/tesis_enzo/login.html"

AQUI = os.path.dirname(os.path.abspath(__file__))
MASCOTA = os.path.join(AQUI, "..", "figuras", "logo_mascota.png")


def qr_base64(url: str) -> str:
    qr = qrcode.QRCode(error_correction=ERROR_CORRECT_H, box_size=20, border=2)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#0A1020", back_color="white").convert("RGB")
    ruta = os.path.join(AQUI, "qr.png")
    img.save(ruta)
    print(f"QR generado · versión {qr.version} · {url}")
    return base64.b64encode(open(ruta, "rb").read()).decode()


def main():
    url = sys.argv[1] if len(sys.argv) > 1 else URL
    plantilla = open(os.path.join(AQUI, "plantilla.html"), encoding="utf-8").read()
    html = (plantilla
            .replace("__QR__", qr_base64(url))
            .replace("__MASCOTA__", base64.b64encode(open(MASCOTA, "rb").read()).decode()))

    salida_html = os.path.join(AQUI, "folleto.html")
    open(salida_html, "w", encoding="utf-8").write(html)

    with sync_playwright() as pw:
        nav = pw.chromium.launch()
        pag = nav.new_page()
        pag.goto("file://" + salida_html, wait_until="load")
        pag.emulate_media(media="print")
        pag.pdf(path=os.path.join(AQUI, "stockIAte_folleto_A5.pdf"),
                width="148mm", height="210mm",
                print_background=True, margin={"top": "0", "bottom": "0", "left": "0", "right": "0"})
        pag.set_viewport_size({"width": 560, "height": 794})
        for i, cara in enumerate(["frente", "dorso"], start=1):
            pag.locator(f".{cara}").screenshot(path=os.path.join(AQUI, f"vista_{i}_{cara}.png"))
        nav.close()

    print("Listo: stockIAte_folleto_A5.pdf")


if __name__ == "__main__":
    main()
