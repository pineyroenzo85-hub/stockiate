require ('dotenv').config()

const checkApiKey = (req,res,next)=>{
    const apikey = req.header('x-api-key')
    if(apikey === process.env.API_KEY){
        next()
    }else{
        res.status(401).json({message: 'Api Key Incorrecta'})
    }
}

module.exports = checkApiKey