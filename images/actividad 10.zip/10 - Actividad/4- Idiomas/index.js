     const express = require('express');
const miapi = express();
require('dotenv').config();
miapi.use(express.json());
const mysql = require('mysql2');

const checkApiKey = require('./middleware/checkApiKey')

const db = mysql.createConnection({
    host:process.env.HOST,
    user:process.env.USER,
    password:process.env.PASSWORD,
    database:process.env.DATABASE,
})

db.connect((error)=>{
    if(error){
        console.error({'message':error.message});
        return;
    }
    console.log("Connection OK")
})

miapi.get('/languages', checkApiKey,(request, results)=>{
    db.query('SELECT * FROM `languages` ORDER BY `language_id` DESC', (error, resultado)=>{
        if(error){
            results.status(500).json({message:error.message})
            return
        }
        results.json(resultado)
    })
})

const PORT = 3000;
miapi.listen(PORT, ()=>{
    console.log("Servidor en: "+PORT)
})